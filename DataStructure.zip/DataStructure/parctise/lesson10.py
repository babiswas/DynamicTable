class A:
  def __init__(self,a,b):
      self.a=a
      self.b=b
  def __call__(self,func):
      print("Call function executed")
      def wrapper(*args,**kwargs):
         print("Wrapper executed")
         return func(*args,**kwargs)
      return wrapper


@A(3,4)
def func(*args):
   for i in args:
      print(i)

if __name__=="__main__":
   print("Executing function")
   func(1,2,3,4)