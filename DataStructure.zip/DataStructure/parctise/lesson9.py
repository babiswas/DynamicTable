from abc import ABC,abstractmethod


class A(ABC):
   @abstractmethod
   def fun1(self,*args):
       pass

   @abstractmethod
   def fun2(self,*args):
       pass


class B(A):
   def fun1(self,*args):
       for i in args:
          print(i)

   def fun2(self,*args):
      for j in args:
         print(j)

if __name__=="__main__":
   b=B()
   b.fun1(1,2,3)
   b.fun2(4,5,6)
   c=A()

   