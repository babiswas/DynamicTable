class A:
  def __init__(self,a):
      self.a=a
  def __iter__(self):
      return self
  def __next__(self):
      if not hasattr(self,'b'):
         self.b=0
      if self.b>self.a:
         raise StopIteration
      item=self.b
      self.b=self.b+1
      return item

if __name__=="__main__":
   a=A(10)
   b=iter(a)
   print(next(b))
   print(next(b))
   print(next(b))
   print(next(b))
   print(next(b))
   print(next(b))
   print(next(b))
   print(next(b))
   print(next(b))
   print(next(b))
   print(next(b))
   print(next(b))
   print(next(b))
      
         
         
      