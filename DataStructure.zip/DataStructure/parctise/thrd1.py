from threading import Thread
from time import sleep


def task(str1):
   print(f"Obtained task {str1}")
   sleep(2)
   print(f"Completed task {str1}")


if __name__=="__main__":
   task_list=["task"+str(i) for i in range(10)]
   thread_list=[Thread(target=task,args=(i,))for i in task_list]
   for t in thread_list:
       t.start()
   for t in thread_list:
       t.join()

   