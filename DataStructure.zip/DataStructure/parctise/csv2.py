import csv

with open('test1.csv','r') as file:
    reader=csv.DictReader(file)
    for row in reader:
        print(row['name'],row['contact'])