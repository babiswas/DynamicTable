def decorator(func):
  print("Decorator executed")
  def wrapper(*args,**kwargs):
       print("Wrapper executed")
       return func(*args,**kwargs)
  return wrapper


@decorator
def display(*args):
    str1=','.join([str(i) for i in args])
    print(str1)


if __name__=="__main__":
   print("Executing display")
   display(1,2,3,4)