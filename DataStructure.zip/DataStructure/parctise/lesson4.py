class A:
   def __init__(self,a,b):
       print("Parent class executing")
       self.a=a
       self.b=b
   def __str__(self):
       return f"{self.a} and {self.b}"

class B(A):
   def __init__(self,*args,**kwargs):
       print("Child class executing")
       super().__init__(*args,**kwargs)

   def __str__(self):
       return super().__str__()

if __name__=="__main__":
   b=B(3,4)
   print(b)
   print(b.__dict__)