import csv

with open("test2.csv",'w',newline='') as file:
     writer=csv.writer(file)
     writer.writerow(['hello','bello','mello'])
     writer.writerow(['nello','tello','gello','chello'])
     writer.writerow(['bello','belllo'])
