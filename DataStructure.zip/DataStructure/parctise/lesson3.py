
if __name__=="__main__":
   l=[12,13,16,1,23,26]
   print(list(map(lambda a:a*2,list(map(lambda x:x**2,l)))))
