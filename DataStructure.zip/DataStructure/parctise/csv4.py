import csv

with open('test2.csv','r') as file:
     reader=csv.reader(file)
     for row in reader:
        print(','.join(row))
