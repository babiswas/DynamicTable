from threading import Thread
from queue import Queue
from time import sleep
import random


def producer(queue):
    while True:
       print("Adding an item in the queue")
       queue.put(random.choice(range(10)))
       print("Added an item in the queue")
       sleep(2)

def consumer(queue):
    while True:
        item=queue.get()
        print(f"Obtained item {item} from queue")
        sleep(2)


if __name__=="__main__":
   queue=Queue()
   th1=Thread(target=producer,args=(queue,))
   th2=Thread(target=consumer,args=(queue,))
   th1.start()
   th2.start()
   th1.join()
   th2.join()
    
    