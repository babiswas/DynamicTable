def knap_sack(arr,brr,n,W):
    if n==0 or W==0:
       return 0
    if n-1>=0:
       if arr[n-1]<=W:
            return max(knap_sack(arr,brr,n-1,W),knap_sack(arr,brr,n-1,W-arr[n-1])+brr[n-1])
       elif arr[n-1]>W:
            return knap_sack(arr,brr,n-1,W)


if __name__=="__main__":
   print(knap_sack([10,20,30],[60,100,120],3,50))
