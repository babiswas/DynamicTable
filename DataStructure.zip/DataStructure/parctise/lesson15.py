def decorator1(func):
   print("Decorator1 executed")
   def wrapper(*args,**kwargs):
       print("Wrapper1 function executed")
       return func(*args,**kwargs)
   return wrapper


def decorator2(func):
    print("Decorator2 Executed")
    def wrapper(*args,**kwargs):
        print("Wrapper 2 executed")
        return func(*args,**kwargs)
    return wrapper


@decorator2
@decorator1
def func(*args):
   for i in args:
      print(i)


if __name__=="__main__":
   print("Decorator function called")
   func("hello","bello","mello")

