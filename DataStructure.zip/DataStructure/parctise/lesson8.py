class A:
   def __init__(self,a):
       self.a=a

   def __add__(self,other):
      if isinstance(other,A):
         return self.a+other.a
      elif isinstance(other,int):
         return self.a+other

   def __radd__(self,other):
      if not other:
         return self
      else:
         return self.__add__(other)

if __name__=="__main__":
   a=A(3)
   b=A(4)
   print(a+b)
   print(a+20)
   print(10+a)
   
   
       