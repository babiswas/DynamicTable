def knap_sack(arr,brr,n,W,T):
    if n==0 or W==0:
       return 0
    if T[n][W]!=-1:
       return T[n][W]
    if n-1>=0:
       if arr[n-1]<=W:
          T[n][W]=max(knap_sack(arr,brr,n-1,W,T),knap_sack(arr,brr,n-1,W-arr[n-1],T)+brr[n-1])
       else:
          T[n][W]=knap_sack(arr,brr,n-1,w,T)
       return T[n][W]

def k_sack(arr,brr,n,W):
    T=[[-1 for i in range(W+1)] for j in range(n+1)]
    return knap_sack(arr,brr,n,W,T)


if __name__=="__main__":
   print(k_sack([10,20,30],[60,100,120],3,50))
    