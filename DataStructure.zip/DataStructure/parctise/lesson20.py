class C:
  def __init__(self,a,b):
      self.a=a
      self.b=b
  def geta(self):
     return self.a
  def getb(self):
     return self.b


class A(type):
   def __new__(cls,classname,baseclassname,attrs):
       print("New method executed in metaclass")
       attrs['getvalue']=C.__dict__['getb']
       return type.__new__(cls,classname,baseclassname,attrs)


class B(metaclass=A):
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def geta(self):
        return self.a


if __name__=="__main__":
   b=B(2,3)
   print(b.geta())
   print(b.getvalue())