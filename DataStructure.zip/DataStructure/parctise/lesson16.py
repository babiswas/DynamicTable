def decorator(*args,**kwargs):
   print("Decorator executed")
   def wrapper(func):
      print("Wrapper class executed")
      return func
   return wrapper


@decorator(test1="hello",test2="bello")
def func():
    print("hello")


if __name__=="__main__":
   print("Executing function")
   func()
   