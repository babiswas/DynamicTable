import csv

with open("test1.csv",'w',newline='') as file:
     writer=csv.DictWriter(file,fieldnames=['name','contact'])
     writer.writeheader()
     writer.writerow({'name':'Bapan','contact':'9954396056'})
     writer.writerow({'name':'Tapan','contact':'6360115781'})
