class A:
  def __init__(self,a,b):
      print("Parent method executed")
      self.a=a
      self.b=b
  def __str__(self):
      return f"{self.a} and {self.b}"


class B(A):
   def __init__(self,*args,**kwargs):
      print("Child method executed")
      A.__init__(self,*args,**kwargs)

if __name__=="__main__":
   a=B(3,4)
   print(a)
   print(a.__dict__)
   
       
 