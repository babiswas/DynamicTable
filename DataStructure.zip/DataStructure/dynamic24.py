def min_insert(str1,str2,m,n):
    if m==0 or n==0:
       return 0
    else:
       if str1[m-1]==str2[n-1]:
          return 1+min_insert(str1,str2,m-1,n-1)
       else:
          return max(min_insert(str1,str2,m-1,n),min_insert(str1,str2,m,n-1))

def find_min_insertion(str1):
    length1=min_insert(str1,str1[::-1],len(str1),len(str1))
    return len(str1)-length1

if __name__=="__main__":
   print("The minimum number of insertion required to convert the string into palindrome is")
   print(find_min_insertion("aebcbda"))
