class Cell:
   def __init__(self,parent,rank):
       self.parent=parent
       self.rank=rank
    

class Graph:
    def __init__(self,vertex):
        self.vertex=vertex
        self.graph=[]

    def add_edges(self,u,v):
        self.graph.append((u,v))

    def find(self,u,rank):
        while rank[u].parent!=-1:
            u=rank[u].parent
        return u


    def union(self,index1,index2,rank):
        if rank[index1].rank>rank[index2].rank:
            rank[index2].parent=index1
        else:
            rank[index1].parent=index2

    def is_cyclic(self):
        rank=[Cell(-1,0) for i in range(self.vertex)]
        for u,v in self.graph:
            index1=self.find(u,rank)
            index2=self.find(v,rank)
            if index1==index2:
                return True
            else:
                self.union(index1,index2,rank)
        return False

if __name__=="__main__":
    graph=Graph(6)
    graph.add_edges(4,1)
    graph.add_edges(4,0)
    graph.add_edges(5,0)
    graph.add_edges(5,2)
    graph.add_edges(2,3)
    print(graph.is_cyclic())
    print("Creating another graph")
    graph=Graph(6)
    graph.add_edges(4,1)
    graph.add_edges(4,0)
    graph.add_edges(5,0)
    graph.add_edges(5,2)
    graph.add_edges(2,3)
    graph.add_edges(3,1)
    print(graph.is_cyclic())
   