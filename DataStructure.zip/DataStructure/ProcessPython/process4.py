from multiprocessing import Process
from multiprocessing import Pipe

def func(conn):
   conn.send([42,None,'hello'])
   conn.close()


if __name__=="__main__":
   p_conn,c_conn=Pipe()
   p1_conn,c1_conn=Pipe()
   p=Process(target=func,args=(c_conn,))
   p1=Process(target=func,args=(c1_conn,))
   p.start()
   p1.start()
   p.join()
   p1.join()
   print(p_conn.recv())
   p_conn.close()
   print(p1_conn.recv())
   p1_conn.close()
   

   