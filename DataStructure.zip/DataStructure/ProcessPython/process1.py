from multiprocessing import Process
from time import sleep


def task(str1,function):
    print(f"Obtained task {str1}")
    sleep(2)
    function(str1)
    print(f"Completed task {str1}")


def task1(str1):
   print(f"{str1} completed")

if __name__=="__main__":
   p1=Process(target=task,args=("hello",task1,))
   p2=Process(target=task,args=("bello",task1,))
   p1.start()
   p2.start()
   p1.join()
   p2.join()

   
    