from multiprocessing import Queue
from multiprocessing import Process
from time import sleep


def task(t,queue):
   print(f"Queuing task {t}")
   queue.put(t)
   


if __name__=="__main__":
   queue=Queue()
   task_list=["task"+str(i) for i in range(10)]
   process_list=[Process(target=task,args=(t,queue,)) for t in task_list]
   for p in process_list:
       p.start()
       p.join()
   while not queue.empty():
       print(queue.get())

   
   